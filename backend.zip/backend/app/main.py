from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import os

from app.routes import auth, vocab, packs

# Try to initialize database if available
try:
    from app.database import Base, engine, SessionLocal
    from app.models import User as DBUser
    
    if engine is not None:
        print("🔧 Creating database tables...")
        Base.metadata.create_all(bind=engine)
        
        # Create admin user if doesn't exist
        db = SessionLocal()
        try:
            admin = db.query(DBUser).filter(DBUser.email == "admin@aac.com").first()
            if not admin:
                from app.routes.auth import _hash_password
                admin = DBUser(
                    id="admin_0000000001",
                    email="admin@aac.com",
                    name="Administrator",
                    role="admin",
                    password_hash=_hash_password("admin123")
                )
                db.add(admin)
                db.commit()
                print("✅ Admin user created in database")
            else:
                print("ℹ️ Admin user already exists")
        except Exception as e:
            print(f"⚠️ Error creating admin user: {e}")
        finally:
            db.close()
except Exception as e:
    print(f"ℹ️ Database initialization skipped: {e}")

app = FastAPI(title="AAC School App API")

# Configure CORS to allow requests from frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:8081",  # Expo dev server
        "http://127.0.0.1:8081",  # Alternative localhost
        "http://localhost:19006",  # Expo web
        "*"  # Allow all in development - restrict in production
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
)

app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(vocab.router, prefix="/vocab", tags=["vocab"])
app.include_router(packs.router, prefix="/packs", tags=["packs"])


@app.get("/")
def health():
    return {"status": "ok"}
