# Pydantic schemas placeholder
