from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os

# Get database URL from environment variable (Railway provides this)
DATABASE_URL = os.getenv("DATABASE_URL")

# Railway sometimes uses 'postgres://' but SQLAlchemy needs 'postgresql://'
if DATABASE_URL and DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

# Create engine and session (only if DATABASE_URL is provided)
if DATABASE_URL:
    engine = create_engine(DATABASE_URL)
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    print("✅ Using PostgreSQL database")
else:
    engine = None
    SessionLocal = None
    print("ℹ️ No DATABASE_URL found - using in-memory storage")

Base = declarative_base()

# Dependency to get DB session
def get_db():
    if SessionLocal is None:
        raise Exception("Database not configured. Set DATABASE_URL environment variable.")
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
